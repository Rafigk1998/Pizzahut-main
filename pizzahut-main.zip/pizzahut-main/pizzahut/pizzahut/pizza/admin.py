from django.contrib import admin
from .models import Size,Pizza
# Register your models here.
admin.site.register(Size)
admin.site.register(Pizza)
