from django.shortcuts import render
from .forms import PizzaForm,MultiplePizzaForm
from .models import Pizza,Size
from django .forms import formset_factory


# Create your views here.
def homepage(request):
    return render(request,'pizza/homepage.html')
def order(request):
    multiple_pizza_form= MultiplePizzaForm()
    if request.method == "POST":
        filled_form = PizzaForm(request.POST)
        if filled_form.is_valid():

           # size_obj=Size.objects.get(title= filled_form.cleaned_data['size'])
            #obj =    Pizza(topping1 = filled_form.cleaned_data['topping1'],
                  #topping2 = filled_form.cleaned_data['topping2'],
                  #size = size_obj)
            filled_form.save()
            note = "Thanks your order for %s,%s,%s size pizza  placed succesfully!!" % (
                                                     filled_form.cleaned_data['topping1'],
                                                     filled_form.cleaned_data['topping2'],
                                                     filled_form.cleaned_data['size'])

        else:
            note="your order not received"
        new_form= PizzaForm()
        return render(request, 'pizza/order.html', {"pizzaform": new_form,"note":note,"multiple_pizza_form":multiple_pizza_form})
    else:
        form=PizzaForm() #empty form
        return render(request,'pizza/order.html',{"pizzaform":form,"multiple_pizza_form": multiple_pizza_form})

def pizzas(request):
    no_of_pizzas = 2
    if request.method == "GET":
        filled_multiple_pizza_form = MultiplePizzaForm(request.GET)
        if filled_multiple_pizza_form.is_valid():
            no_of_pizzas = filled_multiple_pizza_form.cleaned_data["number"]
    print(no_of_pizzas)
    PizzaFormset = formset_factory(PizzaForm,extra=no_of_pizzas) # formset class
    formset= PizzaFormset() #empty formset
    if request.method == "POST":
        filled_formset = PizzaFormset(request.POST)
        if filled_formset.is_valid():
            for form in filled_formset:
                form.save()
            note = "Thanks you order has been received successfully!!"
        else:
            note  = "sorry,order not placed please try again...."
        return render(request, 'pizza/pizzas.html', {"submitted":True,"note":note})
    return render(request,'pizza/pizzas.html',{"formset":formset})


#Edit page
def edit(request):
    edit = MultiplePizzaForm()
    if request.method == "POST":
        form=MultiplePizzaForm(request.POST)
        if form.is_valid():
            form.save()


    return render(request,'pizza/edit.html')

